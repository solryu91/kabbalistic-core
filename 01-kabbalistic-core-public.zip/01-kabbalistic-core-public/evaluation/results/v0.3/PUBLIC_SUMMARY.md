# Historical v0.3 aggregate: null effect

The nonpublic prototype's bounded v0.3 run reported `null_effect` with a mean
graph-minus-neutral difference of -0.35, one graph win, two neutral wins, and
one tie across four prompts. Perspective integration was +1.00; tension
preservation 0.00; actionability -0.50; constraint fidelity -0.75; and epistemic
restraint -1.50.

This file is a public-safe narrative disclosure, not a raw evaluation artifact.
The paired outputs, packet, key, score sheets, source corpus, and historical
hash chain are excluded. See `docs/EVALUATION.md` for interpretation limits.
