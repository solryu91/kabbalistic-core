# Evaluation and null-result record

## What the harness measures

The paired evaluation compares two response pipelines under one intention,
retrieval snapshot, model configuration, call count, and output-token ceiling:

- the full graph treatment, including Form, Flow, Accord, directed observation,
  Tiferet integration, and optional bounded symbolic structure; and
- a neutral evidence/alternatives/consequences pipeline without the Tree route,
  functional kernels, or symbolic recursion.

The evaluation code creates a balanced A/B packet, keeps the condition key
separate, requires every rubric score, hash-seals the score sheet before
unblinding, and applies the declared decision rule. It never converts a small or
mixed difference into a win after the fact.

## Historical aggregate result

An earlier bounded run on the nonpublic prototype completed four eligible,
budget-matched pairs using one local quantized model and one evaluator. Its
primary result was `null_effect`.

| Measure | Graph minus neutral |
| --- | ---: |
| Overall mean | -0.35 |
| Perspective integration | +1.00 |
| Tension preservation | 0.00 |
| Actionability | -0.50 |
| Constraint fidelity | -0.75 |
| Epistemic restraint | -1.50 |

The graph won one prompt, the neutral pipeline won two, and one tied. The
neutral condition was numerically better overall, but it did not meet both
declared thresholds: an absolute mean difference of at least 0.4 and at least
three prompt wins. The result therefore remains null rather than being relabeled
a neutral win.

## Public-edition boundary

This repository includes that aggregate disclosure because preserving an
unfavorable result is part of the engineering record. It does **not** include
the historical raw corpus, paired outputs, evaluator packet, condition key,
score sheets, source locators, or private Git history.

The `preregistered_v0.1.json` through `v0.3.json` files in this edition are
clearly marked `synthetic_public_fixture`. They preserve the public evaluation
API and test protocol evolution with wholly synthetic scenarios. Their hashes
bind these public fixtures only. They are not substituted historical artifacts,
and rerunning them cannot reproduce or validate the earlier aggregate result.

## Interpretation limits

Four prompts and one evaluator do not support statistical generalization. The
run cannot establish consciousness, personhood, relationship development,
metaphysical truth, product efficacy, or general architectural superiority.
Response style may also make conditions guessable despite hidden labels. Future
work should use independently reviewed public prompts, multiple evaluators,
larger samples, calibrated measures, and a new preregistration frozen before any
outcomes are generated.
